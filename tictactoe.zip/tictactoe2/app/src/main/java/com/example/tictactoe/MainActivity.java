package com.example.tictactoe;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button b1, b2, b3, b4, b5, b6, b7, b8, b9;
    int flag = 0; // 0 for "X", 1 for "O"
    int c = 0; // move count

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        setButtonListeners();
    }

    private void init() {
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);
        b6 = findViewById(R.id.b6);
        b7 = findViewById(R.id.b7);
        b8 = findViewById(R.id.b8);
        b9 = findViewById(R.id.b9);
    }

    private void setButtonListeners() {
        b1.setOnClickListener(this::check);
        b2.setOnClickListener(this::check);
        b3.setOnClickListener(this::check);
        b4.setOnClickListener(this::check);
        b5.setOnClickListener(this::check);
        b6.setOnClickListener(this::check);
        b7.setOnClickListener(this::check);
        b8.setOnClickListener(this::check);
        b9.setOnClickListener(this::check);
    }

    public void check(View view) {
        Button Bcurr = (Button) view;
        if (Bcurr.getText().toString().equals("")) { // Check for empty string
            c++;
            if (flag == 0) {
                Bcurr.setText("X");
                flag = 1;
            } else {
                Bcurr.setText("O");
                flag = 0;
            }
            if (c > 4) {
                checkForWinner();
            }
        }
    }

    private void checkForWinner() {
        String bb1 = b1.getText().toString();
        String bb2 = b2.getText().toString();
        String bb3 = b3.getText().toString();
        String bb4 = b4.getText().toString();
        String bb5 = b5.getText().toString();
        String bb6 = b6.getText().toString();
        String bb7 = b7.getText().toString();
        String bb8 = b8.getText().toString();
        String bb9 = b9.getText().toString();

        // Check rows, columns, and diagonals
        if ((bb1.equals(bb2) && bb2.equals(bb3) && !bb1.equals("")) ||
                (bb4.equals(bb5) && bb5.equals(bb6) && !bb4.equals("")) ||
                (bb7.equals(bb8) && bb8.equals(bb9) && !bb7.equals("")) ||
                (bb1.equals(bb4) && bb4.equals(bb7) && !bb1.equals("")) ||
                (bb2.equals(bb5) && bb5.equals(bb8) && !bb2.equals("")) ||
                (bb3.equals(bb6) && bb6.equals(bb9) && !bb3.equals("")) ||
                (bb1.equals(bb5) && bb5.equals(bb9) && !bb1.equals("")) ||
                (bb3.equals(bb5) && bb5.equals(bb7) && !bb3.equals(""))) {
            String winner = bb1.equals("X") ? "X" : "O";
            Toast.makeText(this, "Winner is " + winner, Toast.LENGTH_SHORT).show();
            resetGame();
        } else if (c == 9) {
            Toast.makeText(this, "It's a tie!", Toast.LENGTH_SHORT).show();
            resetGame();
        }
    }

    private void resetGame() {
        b1.setText("");
        b2.setText("");
        b3.setText("");
        b4.setText("");
        b5.setText("");
        b6.setText("");
        b7.setText("");
        b8.setText("");
        b9.setText("");
        c = 0;
        flag = 0;
    }
}
